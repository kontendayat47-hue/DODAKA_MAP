const KUNCI_DATA="usahaDodaka";
const TITIK_AWAL=[-1.0344966,101.6735537];
const dataAwal=[
 {nama:"Toko supek",kategori:"Laundry",alamat:"Blok B",whatsapp:"085219129942",lat:-1.0697072443667706,lng:101.54896438121797,foto:"assets/toko-supek.jpg"},
 {nama:"Makmur bengkel",kategori:"Bengkel",alamat:"Blok B",whatsapp:"08678985",lat:-1.0713821591259023,lng:101.55156612396242,foto:"assets/bengkel.jpg"},
 {nama:"Ampera",kategori:"Rumah Makan",alamat:"Blok B",whatsapp:"",lat:-1.0678038331795667,lng:101.54707144789428,foto:"assets/ampera.jpg"},
 {nama:"Lekman",kategori:"Sembako",alamat:"Blok B",whatsapp:"08",lat:-1.0491129089580877,lng:101.54813289642334,foto:"assets/suasana-blok-b.jpg"},
 {nama:"Pandi",kategori:"Barbershop",alamat:"Blok B",whatsapp:"088",lat:-1.0502720992398886,lng:101.54854059219362,foto:"assets/suasana-blok-b.jpg"},
 {nama:"M HIDAYAT",kategori:"Barbershop",alamat:"Blok B",whatsapp:"",lat:-1.0510,lng:101.5490,foto:"assets/suasana-blok-b.jpg"},
 {nama:"M HIDAYAT",kategori:"Warung",alamat:"Blok B",whatsapp:"",lat:-1.0520,lng:101.5500,foto:"assets/suasana-blok-b.jpg"}
];
let daftarUsaha=[];
function identitas(x){return [x.nama||"",x.kategori||"",x.alamat||""].map(v=>String(v).trim().toLowerCase()).join("|")}
let peta=null,petaTambah=null,penandaSementara=null,lokasiDipilih=null,kategoriAktif="Semua",semuaPenanda=[],indeksBarangDiedit=null;
const ikonKategori={"Warung":"🛒","Sembako":"🛒","Bengkel":"🔧","Laundry":"🧺","Rumah Makan":"🍜","Barbershop":"✂️","Lainnya":"📍"};
function escapeHTML(s){return String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
function buatPeta(el,zoom){
  const map=L.map(el,{zoomControl:true}).setView(TITIK_AWAL,zoom);

  // Peta dasar: citra satelit Esri
  const satelit=L.tileLayer(
    "https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}",
    {
      maxZoom:19,
      attribution:"Tiles &copy; Esri"
    }
  );

  // Lapisan jalan dan batas wilayah di atas citra satelit
  const jalan=L.tileLayer(
    "https://server.arcgisonline.com/ArcGIS/rest/services/Reference/World_Transportation/MapServer/tile/{z}/{y}/{x}",
    {
      maxZoom:19,
      attribution:"Esri"
    }
  );

  // Lapisan nama tempat agar lokasi lebih mudah dikenali
  const namaTempat=L.tileLayer(
    "https://server.arcgisonline.com/ArcGIS/rest/services/Reference/World_Boundaries_and_Places/MapServer/tile/{z}/{y}/{x}",
    {
      maxZoom:19,
      attribution:"Esri"
    }
  );

  // Aktifkan satelit, jalan, dan nama tempat
  satelit.addTo(map);
  jalan.addTo(map);
  namaTempat.addTo(map);

  // Pengguna dapat berpindah antara peta satelit dan peta jalan
  const petaJalan=L.tileLayer(
    "https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png",
    {
      maxZoom:19,
      attribution:"&copy; OpenStreetMap contributors"
    }
  );
  L.control.layers(
    {"Satelit":satelit,"Peta jalan":petaJalan},
    {"Jalan & batas":jalan,"Nama tempat":namaTempat},
    {collapsed:true}
  ).addTo(map);

  return map;
}
function mulaiPeta(){if(!window.L)return; peta=buatPeta("peta",15);peta.on("click",e=>{if(document.getElementById("form-usaha").classList.contains("hidden"))return;lokasiDipilih=e.latlng;if(penandaSementara)penandaSementara.remove();penandaSementara=L.marker(e.latlng).addTo(peta).bindPopup("Lokasi usaha dipilih").openPopup()});petaTambah=buatPeta("peta-tambah",15);petaTambah.on("click",e=>{lokasiDipilih=e.latlng;if(penandaSementara)penandaSementara.remove();penandaSementara=L.marker(e.latlng).addTo(petaTambah).bindPopup("Lokasi usaha dipilih").openPopup()});document.querySelectorAll(".category").forEach(b=>b.addEventListener("click",()=>{pilihKategoriDanBukaPeta(b.dataset.kategori)}));tampilkanSemuaUsaha()}
function pilihKategoriDanBukaPeta(kategori){
  kategoriAktif=kategori||"Semua";
  document.querySelectorAll(".category").forEach(b=>b.classList.toggle("active",b.dataset.kategori===kategoriAktif));
  const cariBeranda=document.getElementById("kolom-cari");
  const cariLengkap=document.getElementById("cari-usaha-lengkap");
  if(cariBeranda)cariBeranda.value="";
  if(cariLengkap)cariLengkap.value="";
  const cariPeta=document.getElementById("map-search-input");if(cariPeta)cariPeta.value="";
  perbaruiInfoFilterPeta();
  kePeta();
  setTimeout(()=>{tampilkanSemuaUsaha();if(peta)peta.invalidateSize()},220);
}
function perbaruiInfoFilterPeta(){
  const label=document.getElementById("label-filter-peta");
  const judul=document.getElementById("judul-peta-kategori");
  const deskripsi=document.getElementById("deskripsi-peta-kategori");
  if(label)label.textContent=kategoriAktif==="Semua"?"Semua kategori":"Kategori: "+kategoriAktif;
  if(judul)judul.textContent=kategoriAktif==="Semua"?"Temukan toko di peta":"Peta usaha "+kategoriAktif;
  if(deskripsi)deskripsi.textContent=kategoriAktif==="Semua"?"Blok B · Sitiung 1 · Dharmasraya":"Lokasi usaha kategori "+kategoriAktif+" di Blok B";
  document.querySelectorAll(".map-category-chip").forEach(b=>b.classList.toggle("active",b.dataset.mapKategori===kategoriAktif));
}
function resetKategoriPeta(){pilihKategoriDanBukaPeta("Semua")}
function ikonToko(k){return ikonKategori[k]||"📍"}
function kontenPopupToko(t){
  const foto=escapeHTML(fotoAman(t.foto));
  const wa=nomorWA(t.whatsapp);
  const status=t.statusToko||"Belum diatur";
  const statusClass=status==="Buka"?"is-open":"is-closed";
  const arah=(Number.isFinite(Number(t.lat))&&Number.isFinite(Number(t.lng)))?`https://www.google.com/maps/dir/?api=1&destination=${encodeURIComponent(t.lat+","+t.lng)}`:"#";
  const barang=(t.barang||[]).slice(0,4).map(b=>`<div class="map-popup-product">${b.foto?`<img src="${escapeHTML(fotoAman(b.foto))}" alt="">`:""}<span><b>${escapeHTML(b.nama)}</b><small>Stok: ${Number(b.stok)||0}${b.harga?` · Rp ${escapeHTML(b.harga)}`:""}</small></span></div>`).join("");
  return `<div class="map-shop-popup"><img class="map-popup-cover" src="${foto}" alt="Foto ${escapeHTML(t.nama)}" onerror="this.src='assets/suasana-blok-b.jpg'"><div class="map-popup-body"><h3>${escapeHTML(t.nama)}</h3><p class="map-popup-category">${ikonToko(t.kategori)} ${escapeHTML(t.kategori||"Usaha")}</p><p>📍 ${escapeHTML(t.alamat||"Alamat belum diisi")}</p><p class="shop-status ${statusClass}">● ${escapeHTML(status)}</p>${barang?`<div class="map-popup-stock"><b>Info barang</b>${barang}</div>`:""}<div class="map-popup-actions">${wa?`<a class="map-popup-wa" target="_blank" rel="noopener" href="https://wa.me/${wa}">WhatsApp</a>`:""}<a class="map-popup-directions" target="_blank" rel="noopener" href="${arah}">Petunjuk arah</a></div></div></div>`;
}
function tampilkanSemuaUsaha(){if(!peta)return;semuaPenanda.forEach(m=>m.remove());semuaPenanda=[];const q=(document.getElementById("kolom-cari")?.value||"").toLowerCase().trim();const hasil=daftarUsaha.filter(t=>{const cocok=[t.nama,t.kategori,t.alamat].join(" ").toLowerCase().includes(q);const kat=kategoriAktif==="Semua"|| t.kategori===kategoriAktif||(kategoriAktif==="Lainnya"&&!Object.keys(ikonKategori).includes(t.kategori));return cocok&&kat&&!t.dinonaktif&&(t.bawaan||t.status==='disetujui')});const infoPeta=document.getElementById("jumlah-peta-kategori");if(infoPeta)infoPeta.textContent=hasil.length+" usaha ditemukan pada kategori ini";hasil.forEach(t=>{if(Number.isFinite(Number(t.lat))&&Number.isFinite(Number(t.lng))){const marker=L.marker([Number(t.lat),Number(t.lng)],{icon:L.divIcon({className:"dodaka-map-marker-wrap",html:`<span class="dodaka-map-marker ${t.statusToko==="Buka"?"status-open":t.statusToko==="Tutup"?"status-closed":"status-unknown"}"><i>${ikonToko(t.kategori)}</i></span>`,iconSize:[38,44],iconAnchor:[19,39]})}).addTo(peta).bindTooltip(escapeHTML(t.nama),{permanent:true,direction:"top",offset:[0,-28],className:"business-label"});marker.bindPopup(kontenPopupToko(t),{maxWidth:290,minWidth:230,closeButton:true,autoPan:true});semuaPenanda.push(marker)}});document.getElementById("jumlah-usaha").textContent=hasil.length+" usaha ditemukan";const wadah=document.getElementById("kartu-usaha");wadah.innerHTML=hasil.map((t,i)=>{const wa=nomorWA(t.whatsapp);const foto=fotoAman(t.foto);const arah=Number.isFinite(Number(t.lat))&&Number.isFinite(Number(t.lng))?`https://www.google.com/maps/dir/?api=1&destination=${Number(t.lat)},${Number(t.lng)}`:"#";return `<article class="business-card"><img src="${escapeHTML(foto)}" alt="Foto ${escapeHTML(t.nama)}" onerror="this.src='assets/suasana-blok-b.jpg'"><div class="business-info"><h3>${escapeHTML(t.nama)}</h3><p>${ikonToko(t.kategori)} ${escapeHTML(t.kategori)}</p><p>📍 ${escapeHTML(t.alamat||"Alamat belum diisi")}</p><p class="shop-status ${t.statusToko==='Buka'?'is-open':t.statusToko==='Tutup'?'is-closed':'is-unknown'}">● ${escapeHTML(t.statusToko||'Status belum diatur')}</p>${(t.barang||[]).length?`<div class="buyer-products"><b>Barang tersedia</b>${t.barang.map(b=>`<div class="buyer-product">${b.foto?`<img src="${escapeHTML(fotoAman(b.foto))}" alt="">`:''}<span><b>${escapeHTML(b.nama)}</b><small>Stok: ${Number(b.stok)||0} · ${escapeHTML(b.keterangan||'')}</small>${b.harga?`<small>Rp ${escapeHTML(b.harga)}</small>`:''}</span></div>`).join('')}</div>`:''}<div class="card-actions">${wa?`<a target="_blank" rel="noopener" href="https://wa.me/${wa}">WhatsApp</a>`:""}<a target="_blank" rel="noopener" href="${arah}">Petunjuk arah</a></div></div></article>`}).join("");const ringkas=document.getElementById("ringkas-usaha");if(ringkas)ringkas.innerHTML=wadah.innerHTML.slice(0,12000)}
function nomorWA(n){let x=String(n||"").replace(/\D/g,"");if(x.startsWith("0"))x="62"+x.slice(1);return x}
function keLokasiAwal(){if(peta)peta.setView(TITIK_AWAL,15)}
function gunakanLokasiSaya(){if(!peta)return;if(!navigator.geolocation){alert("HP atau browser tidak mendukung lokasi.");return}navigator.geolocation.getCurrentPosition(pos=>{const titik=[pos.coords.latitude,pos.coords.longitude];peta.setView(titik,17);if(window.penandaLokasiSaya)window.penandaLokasiSaya.remove();window.penandaLokasiSaya=L.circleMarker(titik,{radius:9,color:"#fff",weight:3,fillColor:"#1688ff",fillOpacity:1}).addTo(peta).bindPopup("Lokasi Anda").openPopup()},()=>alert("Lokasi belum dapat diakses. Aktifkan GPS dan izinkan akses lokasi."),{enableHighAccuracy:true,timeout:12000,maximumAge:60000})}
document.addEventListener("DOMContentLoaded",mulaiPeta);
if("serviceWorker" in navigator)window.addEventListener("load",()=>navigator.serviceWorker.register("./service-worker.js").catch(()=>{}));

// ===== AKUN, DATABASE ONLINE (FIREBASE), PENJUAL, ADMIN =====
// Data akun dan usaha disimpan di Firebase (Auth + Firestore) sehingga dapat dilihat semua HP.
// Hak akses yang sebenarnya dijaga oleh aturan Firestore (lihat firestore.rules), bukan oleh kode ini.
const ADMIN_HP="6285219129942";
const DOMAIN_EMAIL="@dodaka.app";
const ADMIN_EMAIL=ADMIN_HP+DOMAIN_EMAIL;
let profilTertunda=null,fbAuth=null,fbDb=null,fbSiap=false,sedangDaftar=false,pemantau=[];
let usahaPublik=[],usahaSaya=[],usahaSemua=[],akunSemua=[],riwayatAdmin=[],usahaSayaDimuat=false;
window.akunAktif=null;

function normalisasiNomorHP(n){let x=String(n||"").replace(/\D/g,"");if(x.startsWith("0"))x=x.slice(1);if(x.startsWith("62"))x=x.slice(2);return "62"+x;}
function idAman(id){return String(id||"").replace(/[^A-Za-z0-9_-]/g,"")}
function fotoAman(f){f=String(f||"");return(/^data:image\/(jpeg|png|webp|gif);base64,[A-Za-z0-9+\/=]+$/.test(f)||/^assets\/[A-Za-z0-9._-]+$/.test(f))?f:"assets/suasana-blok-b.jpg"}
function ambilDok(d){return Object.assign({id:d.id},d.data())}
function pesanAuth(t){const el=document.getElementById("auth-pesan");if(el)el.textContent=t||""}
function tampilAuth(id){document.querySelectorAll(".auth-view").forEach(x=>x.classList.add("hidden"));document.getElementById(id).classList.remove("hidden");pesanAuth("")}
function bukaDaftar(){tampilAuth("form-daftar")}function bukaLogin(){tampilAuth("form-login")}function kembaliAuth(){tampilAuth("auth-choice")}
function pesanErrorAuth(e){
 const c=(e&&e.code)||"";
 if(c==="auth/email-already-in-use")return"Nomor HP sudah terdaftar. Silakan login.";
 if(["auth/invalid-credential","auth/wrong-password","auth/user-not-found","auth/invalid-login-credentials"].includes(c))return"Nomor HP atau kata sandi salah.";
 if(c==="auth/weak-password")return"Password terlalu lemah. Gunakan minimal 6 karakter.";
 if(c==="auth/network-request-failed")return"Tidak ada koneksi internet. Coba lagi.";
 if(c==="auth/too-many-requests")return"Terlalu banyak percobaan. Tunggu beberapa menit lalu coba lagi.";
 if(c==="auth/operation-not-allowed")return"Login email/password belum diaktifkan di Firebase.";
 if(c==="permission-denied")return"Akses ditolak oleh server. Periksa aturan Firestore.";
 return"Terjadi kesalahan ("+(c||(e&&e.message)||"tidak diketahui")+").";
}
function pesanErrorData(e){
 const c=(e&&e.code)||"";
 if(c==="permission-denied")return"Aksi ditolak oleh server. Pastikan Anda sudah login dan memiliki izin.";
 if(c==="unavailable"||c==="auth/network-request-failed")return"Tidak ada koneksi internet. Coba lagi.";
 return"Terjadi kesalahan: "+((e&&e.message)||c||"tidak diketahui");
}
// Menjalankan penulisan ke database dengan pesan hasil yang jelas.
async function jalankan(fn,sukses){
 let selesai=false;
 const batas=setTimeout(()=>{if(!selesai)alert("Koneksi lambat atau tidak ada internet. Perubahan akan terkirim otomatis saat internet kembali.")},15000);
 try{await fn();selesai=true;clearTimeout(batas);if(sukses)alert(sukses);return true}
 catch(e){selesai=true;clearTimeout(batas);console.error(e);alert(pesanErrorData(e));return false}
}
function kompresGambar(file,sisiMaks,kualitas,maksKarakter){
 return new Promise((res,rej)=>{
  if(!file||!String(file.type).startsWith("image/"))return rej(new Error("File harus berupa gambar."));
  if(file.size>8000000)return rej(new Error("Ukuran foto terlalu besar (maksimal 8 MB)."));
  const url=URL.createObjectURL(file),img=new Image();
  img.onload=()=>{
   URL.revokeObjectURL(url);
   let sisi=sisiMaks,q=kualitas,out="";
   for(let i=0;i<8;i++){
    const s=Math.min(1,sisi/Math.max(img.width,img.height));
    const c=document.createElement("canvas");c.width=Math.max(1,Math.round(img.width*s));c.height=Math.max(1,Math.round(img.height*s));
    c.getContext("2d").drawImage(img,0,0,c.width,c.height);
    out=c.toDataURL("image/jpeg",q);
    if(!maksKarakter||out.length<=maksKarakter)break;
    if(q>0.45)q-=0.1;else sisi=Math.round(sisi*0.75);
   }
   if(maksKarakter&&out.length>maksKarakter)return rej(new Error("Foto terlalu besar. Pilih foto lain."));
   res(out);
  };
  img.onerror=()=>{URL.revokeObjectURL(url);rej(new Error("Gambar tidak dapat dibaca."))};
  img.src=url;
 });
}

// ----- Firebase: siapkan, login, daftar -----
function mulaiFirebase(){
 const cfg=window.FIREBASE_CONFIG;
 if(!window.firebase)return"Tidak dapat memuat layanan database. Periksa koneksi internet lalu buka ulang aplikasi.";
 if(!cfg||!cfg.apiKey||!cfg.projectId||/^ISI/i.test(cfg.apiKey)||/^ISI/i.test(cfg.projectId))return"Database online belum disiapkan. Isi file firebase-config.js terlebih dahulu.";
 try{
  if(!firebase.apps.length)firebase.initializeApp(cfg);
  fbAuth=firebase.auth();fbDb=firebase.firestore();
  try{fbDb.settings({experimentalAutoDetectLongPolling:true,merge:true})}catch(e){}
  fbSiap=true;return"";
 }catch(e){console.error(e);return"Gagal menyiapkan database: "+((e&&e.message)||e)}
}
async function muatProfil(user){
 if(String(user.email||"").toLowerCase()===ADMIN_EMAIL)return{uid:user.uid,nama:"Admin DODAKA MAP",hp:ADMIN_HP,peran:"admin"};
 const snap=await fbDb.collection("users").doc(user.uid).get();
 if(!snap.exists)return null;
 const d=snap.data();
 return{uid:user.uid,nama:d.nama||"Pengguna",hp:d.hp,peran:d.peran==="penjual"?"penjual":"pembeli",dinonaktif:!!d.dinonaktif,wajibUbahSandi:d.wajibUbahSandi===true,foto:typeof d.foto==="string"?d.foto:""};
}
function pasangAuth(){
 let pertama=true;
 fbAuth.onAuthStateChanged(async user=>{
  if(sedangDaftar)return;
  const awal=pertama;pertama=false;
  if(!user){bersihkanSesi();if(awal)tampilAuth("auth-choice");return}
  if(window.akunAktif&&window.akunAktif.uid===user.uid)return;
  try{
   const profil=await muatProfil(user);
   if(!profil){await fbAuth.signOut();tampilAuth("auth-choice");pesanAuth("Profil akun tidak ditemukan. Silakan daftar ulang.");return}
   if(profil.dinonaktif){await fbAuth.signOut();tampilAuth("auth-choice");pesanAuth("Akun ini dinonaktifkan oleh Admin.");return}
   if(profil.wajibUbahSandi){profilTertunda=profil;tampilAuth("form-sandi-wajib");document.getElementById("auth-loading")?.classList.add("hidden");document.getElementById("auth-gate").classList.remove("hidden");return}
   buatSesi(profil);
  }catch(e){console.error(e);tampilAuth("auth-choice");pesanAuth(pesanErrorAuth(e))}
 });
}
async function daftarAkun(e){
 e.preventDefault();
 if(!fbSiap){pesanAuth("Database online belum siap. Coba buka ulang aplikasi.");return}
 const hp=normalisasiNomorHP(document.getElementById("auth-hp").value),pass=document.getElementById("auth-pass").value;
 if(!/^62[0-9]{8,13}$/.test(hp)){pesanAuth("Masukkan nomor HP yang valid.");return}
 if(pass.length<6){pesanAuth("Password minimal 6 karakter.");return}
 if(hp===ADMIN_HP){pesanAuth("Nomor ini khusus akun Admin.");return}
 const peran=document.querySelector("input[name='jenis-akun']:checked")?.value==="penjual"?"penjual":"pembeli";
 const tombol=e.target.querySelector("button.primary-button");if(tombol)tombol.disabled=true;
 pesanAuth("Membuat akun...");
 sedangDaftar=true;let cred=null;
 try{
  cred=await fbAuth.createUserWithEmailAndPassword(hp+DOMAIN_EMAIL,pass);
  const profil={nama:"Pengguna "+hp.slice(-4),hp,peran,dibuat:Date.now(),dinonaktif:false};
  await fbDb.collection("users").doc(cred.user.uid).set(profil);
  sedangDaftar=false;
  buatSesi(Object.assign({uid:cred.user.uid},profil));
 }catch(err){
  console.error(err);sedangDaftar=false;
  if(cred&&cred.user){try{await cred.user.delete()}catch(_){try{await fbAuth.signOut()}catch(__){}}}
  pesanAuth(pesanErrorAuth(err));
 }finally{if(tombol)tombol.disabled=false}
}
async function loginAkun(e){
 e.preventDefault();
 if(!fbSiap){pesanAuth("Database online belum siap. Coba buka ulang aplikasi.");return}
 const hp=normalisasiNomorHP(document.getElementById("login-hp").value),pass=document.getElementById("login-pass").value;
 const tombol=e.target.querySelector("button.primary-button");if(tombol)tombol.disabled=true;
 pesanAuth("Masuk...");
 try{await fbAuth.signInWithEmailAndPassword(hp+DOMAIN_EMAIL,pass);pesanAuth("")}
 catch(err){console.error(err);pesanAuth(pesanErrorAuth(err))}
 finally{if(tombol)tombol.disabled=false}
}
function infoAkunHTML(a){return`<p><b>${escapeHTML(a.nama)}</b></p><p>Jenis akun: <b>${escapeHTML(a.peran.toUpperCase())}</b></p>`}
function isiHeaderProfil(a){
 const el=id=>document.getElementById(id);
 const kata=String(a.nama||"?").trim().split(/\s+/).filter(Boolean);
 const inisial=((kata[0]||"?")[0]+(kata.length>1?kata[kata.length-1][0]:"")).toUpperCase();
 const label={admin:"AKUN ADMIN",penjual:"AKUN PENJUAL",pembeli:"AKUN PEMBELI"}[a.peran]||"RUANG AKUN";
 const hp=String(a.hp||"");const nomor=hp.startsWith("62")?"0"+hp.slice(2):hp;
 const av=el("profil-avatar");
 if(av){
  av.textContent="";
  if(/^data:image\/(jpeg|png|webp);base64,[A-Za-z0-9+\/=]+$/.test(a.foto||"")){const im=document.createElement("img");im.src=a.foto;im.alt="Foto profil";av.appendChild(im)}
  else av.textContent=inisial;
 }
 if(el("profil-ruang"))el("profil-ruang").textContent=label;
 if(el("profil-judul"))el("profil-judul").textContent=a.nama||"Profil";
 if(el("profil-sub"))el("profil-sub").textContent=nomor?"Nomor HP: "+nomor:"Kelola akun dan aktivitasmu.";
 if(el("info-pembeli"))el("info-pembeli").classList.toggle("hidden",a.peran!=="pembeli");
 const blok=el("blok-profil-saya");
 if(blok){blok.classList.toggle("hidden",a.peran==="admin");if(el("pf-nama"))el("pf-nama").value=a.nama||""}
}
async function perbaruiAkun(data,sukses){
 const a=window.akunAktif;if(!a||!fbDb||a.peran==="admin")return false;
 const ok=await jalankan(()=>fbDb.collection("users").doc(a.uid).update(data),sukses);
 if(ok){Object.assign(a,data);document.getElementById("info-akun").innerHTML=infoAkunHTML(a);isiHeaderProfil(a)}
 return ok;
}
async function simpanNamaAkun(){
 const nama=document.getElementById("pf-nama").value.trim().replace(/\s+/g," ").slice(0,60);
 if(!nama){alert("Nama tidak boleh kosong.");return}
 await perbaruiAkun({nama},"Nama disimpan.");
}
async function simpanFotoAkun(input){
 const f=input.files&&input.files[0];if(!f)return;
 let foto;try{foto=await kompresGambar(f,320,.8,55000)}catch(e){alert(e.message);input.value="";return}
 await perbaruiAkun({foto},"Foto profil disimpan.");input.value="";
}
async function hapusFotoAkun(){
 if(!window.akunAktif||!window.akunAktif.foto){alert("Belum ada foto profil.");return}
 await perbaruiAkun({foto:""},"Foto profil dihapus.");
}
function buatSesi(a){
 window.akunAktif=a;
 document.getElementById("auth-loading")?.classList.add("hidden");
 document.getElementById("auth-gate").classList.add("hidden");
 if(typeof keBeranda==="function")keBeranda();
 document.getElementById("info-akun").innerHTML=infoAkunHTML(a);
 isiHeaderProfil(a);
 aturHakAkses();
 mulaiPemantau();
 if(a.peran==="penjual"){siapkanPilihanTokoPenjual();keKelolaPenjual()}
}
function bersihkanSesi(){
 hentikanPemantau();window.akunAktif=null;
 bangunDaftarUsaha();if(peta)tampilkanSemuaUsaha();
 document.getElementById("auth-loading")?.classList.add("hidden");
 document.getElementById("auth-gate").classList.remove("hidden");
 if(!document.querySelector(".auth-view:not(.hidden)"))tampilAuth("auth-choice");
}
async function keluarAkun(){
 try{if(fbAuth)await fbAuth.signOut()}catch(e){console.error(e)}
 hentikanPemantau();window.akunAktif=null;
 bangunDaftarUsaha();if(peta)tampilkanSemuaUsaha();
 document.getElementById("auth-gate").classList.remove("hidden");kembaliAuth();kePeta();
}

// ----- Pemantau data (realtime) -----
function bangunDaftarUsaha(){
 const adaDiDb=new Set((usahaSemua.length?usahaSemua:usahaPublik).map(identitas));
 const bawaan=dataAwal.filter(t=>!adaDiDb.has(identitas(t))).map(t=>Object.assign({},t,{bawaan:true,status:"disetujui"}));
 daftarUsaha=bawaan.concat(usahaPublik);
}
function hentikanPemantau(){
 pemantau.forEach(f=>{try{f()}catch(e){}});pemantau=[];
 usahaPublik=[];usahaSaya=[];usahaSemua=[];akunSemua=[];riwayatAdmin=[];usahaSayaDimuat=false;
 const reg=document.getElementById("seller-register");if(reg){delete reg.dataset.diatur;reg.open=false}
}
function mulaiPemantau(){
 hentikanPemantau();
 const a=window.akunAktif;if(!a||!fbDb)return;
 const gal=e=>console.error("Pemantau data gagal:",e);
 pemantau.push(fbDb.collection("usaha").where("status","==","disetujui").onSnapshot(s=>{usahaPublik=s.docs.map(ambilDok);bangunDaftarUsaha();tampilkanSemuaUsaha()},gal));
 if(a.peran==="penjual")pemantau.push(fbDb.collection("usaha").where("ownerUid","==",a.uid).onSnapshot(s=>{usahaSaya=s.docs.map(ambilDok);usahaSayaDimuat=true;segarkanPenjual()},gal));
 if(a.peran==="admin"){
  pemantau.push(fbDb.collection("usaha").onSnapshot(s=>{usahaSemua=s.docs.map(ambilDok);bangunDaftarUsaha();tampilkanSemuaUsaha();aturHakAkses();muatPanelAdmin()},gal));
  pemantau.push(fbDb.collection("users").onSnapshot(s=>{akunSemua=s.docs.map(ambilDok);muatPanelAdmin()},gal));
  pemantau.push(fbDb.collection("riwayat").orderBy("waktu","desc").limit(50).onSnapshot(s=>{riwayatAdmin=s.docs.map(ambilDok);muatPanelAdmin()},gal));
 }
}

// ----- Hak akses tampilan -----
function aturHakAkses(){
 const admin=window.akunAktif?.peran==="admin",penjual=window.akunAktif?.peran==="penjual";
 const kelola=document.getElementById("menu-kelola-penjual");if(kelola)kelola.classList.toggle("hidden",!penjual);
 document.querySelectorAll('[onclick="keTambah()"]').forEach(b=>b.classList.toggle("hidden",!admin));
 const tambahNav=document.querySelector('.bottom-nav button[onclick="keTambah()"]');if(tambahNav)tambahNav.classList.toggle("hidden",!admin);
 const menuTambah=document.getElementById("menu-tambah-usaha");if(menuTambah)menuTambah.classList.toggle("hidden",!admin);
 if(!admin&&document.getElementById("form-usaha"))document.getElementById("form-usaha").classList.add("hidden");
 const menunggu=usahaSemua.filter(t=>t.status==="menunggu").length;
 const menu=document.getElementById("menu-profil-role");
 if(menu)menu.innerHTML=admin?`<button class="primary-button" onclick="keAdmin()">Buka Panel Admin${menunggu?` (${menunggu} menunggu persetujuan)`:""}</button><button class="secondary-button" onclick="keTambah()">Tambah usaha</button>`:penjual?`<button class="primary-button" onclick="keKelolaPenjual()">TOKO SAYA</button>`:"";
}

// ----- Admin menambah usaha langsung (otomatis disetujui) -----
async function simpanUsaha(){
 if(!window.akunAktif||window.akunAktif.peran!=="admin"){alert("Hanya admin yang boleh menambahkan toko.");return}
 const nama=document.getElementById("nama").value.trim(),kategori=document.getElementById("kategori-usaha").value,alamat=document.getElementById("alamat").value.trim(),whatsapp=document.getElementById("whatsapp").value.trim();
 if(!nama||!kategori||!alamat){alert("Lengkapi nama, kategori, dan alamat usaha.");return}
 if(!lokasiDipilih){alert("Ketuk peta untuk memilih lokasi usaha.");return}
 const ok=await jalankan(()=>fbDb.collection("usaha").add({nama,kategori,alamat,whatsapp,lat:lokasiDipilih.lat,lng:lokasiDipilih.lng,foto:"assets/suasana-blok-b.jpg",barang:[],statusToko:"",status:"disetujui",ownerUid:"",ownerHp:"",dibuat:Date.now(),diperbarui:Date.now(),dinonaktif:false}),"Usaha berhasil disimpan.");
 if(!ok)return;
 catatAdmin("Menambah usaha "+nama);
 ["nama","alamat","whatsapp"].forEach(id=>document.getElementById(id).value="");document.getElementById("kategori-usaha").value="";
 if(penandaSementara){penandaSementara.remove();penandaSementara=null}lokasiDipilih=null;
 kePeta();
}

// ----- Penjual: daftarkan usaha, kelola toko -----
let petaDaftarPenjual=null;
window.lokasiDaftarPenjual=null;
function siapkanPetaDaftarPenjual(){
 const el=document.getElementById("peta-daftar-penjual");if(!el||!window.L)return;
 if(!petaDaftarPenjual){
  petaDaftarPenjual=buatPeta("peta-daftar-penjual",16);
  petaDaftarPenjual.on("click",e=>{
   window.lokasiDaftarPenjual={lat:e.latlng.lat,lng:e.latlng.lng};
   if(window.markerDaftarPenjual)window.markerDaftarPenjual.remove();
   window.markerDaftarPenjual=L.marker(e.latlng).addTo(petaDaftarPenjual).bindPopup("Lokasi usaha yang diajukan").openPopup();
   document.getElementById("lokasi-daftar-label").textContent="Lokasi dipilih: "+e.latlng.lat.toFixed(6)+", "+e.latlng.lng.toFixed(6);
  });
 }
 setTimeout(()=>petaDaftarPenjual.invalidateSize(),300);
}
async function ajukanUsahaBaru(){
 const a=window.akunAktif;
 if(!a||a.peran!=="penjual"){alert("Hanya akun penjual yang dapat mendaftarkan usaha.");return}
 const nama=document.getElementById("daftar-nama").value.trim(),kategori=document.getElementById("daftar-kategori-usaha").value,alamat=document.getElementById("daftar-alamat").value.trim(),whatsapp=document.getElementById("daftar-whatsapp").value.trim(),file=document.getElementById("daftar-foto").files[0];
 if(!nama||!kategori||!alamat){alert("Lengkapi nama, kategori, dan alamat usaha.");return}
 if(!window.lokasiDaftarPenjual){alert("Ketuk peta untuk memilih lokasi usaha.");return}
 let foto="assets/suasana-blok-b.jpg";
 if(file){try{foto=await kompresGambar(file,800,0.72,200000)}catch(e){alert(e.message);return}}
 const tombol=document.getElementById("tombol-ajukan-usaha");if(tombol)tombol.disabled=true;
 const ok=await jalankan(()=>fbDb.collection("usaha").add({nama,kategori,alamat,whatsapp,lat:window.lokasiDaftarPenjual.lat,lng:window.lokasiDaftarPenjual.lng,foto,barang:[],statusToko:"",status:"menunggu",ownerUid:a.uid,ownerHp:a.hp,dibuat:Date.now(),diperbarui:Date.now(),dinonaktif:false}),"Usaha berhasil dikirim. Usaha akan tampil di peta setelah disetujui Admin.");
 if(tombol)tombol.disabled=false;
 if(!ok)return;
 ["daftar-nama","daftar-alamat","daftar-whatsapp","daftar-foto"].forEach(id=>document.getElementById(id).value="");document.getElementById("daftar-kategori-usaha").value="";
 if(window.markerDaftarPenjual){window.markerDaftarPenjual.remove();window.markerDaftarPenjual=null}
 window.lokasiDaftarPenjual=null;document.getElementById("lokasi-daftar-label").textContent="";
 const reg=document.getElementById("seller-register");if(reg)reg.open=false;
}
function tokoPemilikAktif(){
 const id=document.getElementById("penjual-pilih-toko")?.value;if(!id)return null;
 const t=usahaSaya.find(x=>x.id===id);return t?{t,id}:null;
}
function pilihTokoPemilik(id){
 if(!usahaSaya.some(x=>x.id===id)){alert("Toko ini bukan milik akun Anda.");return}
 document.getElementById("penjual-pilih-toko").value=id;
 muatKelolaToko();
 document.getElementById("penjual-kelola-form")?.scrollIntoView({behavior:"smooth",block:"start"});
}
function statusPengajuanTeks(s){return s==="disetujui"?"Disetujui · tampil di peta":s==="ditolak"?"Ditolak Admin":"Menunggu persetujuan Admin"}
function segarkanPenjual(){
 if(window.akunAktif?.peran!=="penjual")return;
 const form=document.getElementById("penjual-kelola-form"),ae=document.activeElement;
 const menulis=!!(form&&ae&&form.contains(ae)&&["INPUT","TEXTAREA","SELECT"].includes(ae.tagName));
 siapkanPilihanTokoPenjual(menulis);
}
function siapkanPilihanTokoPenjual(jagaForm){
 const milik=usahaSaya.slice().sort((a,b)=>(b.dibuat||0)-(a.dibuat||0));
 const list=document.getElementById("seller-store-list"),info=document.getElementById("seller-approval-info"),form=document.getElementById("penjual-kelola-form"),input=document.getElementById("penjual-pilih-toko");
 if(list)list.innerHTML=milik.map(t=>`<article class="seller-store-card"><img src="${escapeHTML(fotoAman(t.foto))}" alt="Foto ${escapeHTML(t.nama)}" onerror="this.src='assets/suasana-blok-b.jpg'"><div class="seller-store-card-info"><b>${escapeHTML(t.nama)}</b><small>${escapeHTML(t.alamat||"Alamat belum diisi")}</small><span class="shop-status ${t.statusToko==="Buka"?"is-open":t.statusToko==="Tutup"?"is-closed":"is-unknown"}">${t.statusToko==="Buka"?"● BUKA":t.statusToko==="Tutup"?"● TUTUP":"● BELUM DIKETAHUI"}</span><small>Pengajuan: ${escapeHTML(statusPengajuanTeks(t.status))}</small></div><button type="button" class="primary-button" onclick="pilihTokoPemilik('${idAman(t.id)}')">Kelola toko</button></article>`).join("")||(usahaSayaDimuat?'<div class="approval-note">Akun ini belum memiliki usaha. Daftarkan usaha Anda melalui menu "Daftarkan usaha baru" di bawah.</div>':'<div class="approval-note">Memuat data usaha...</div>');
 if(info)info.innerHTML=milik.filter(t=>t.status!=="disetujui").map(t=>t.status==="ditolak"?`<div class="approval-note"><b>${escapeHTML(t.nama)}</b><p>Status pengajuan: <strong>Ditolak</strong></p>${t.catatanAdmin?`<p>Catatan Admin: ${escapeHTML(t.catatanAdmin)}</p>`:""}<p>Perbaiki data usaha lalu ajukan ulang.</p><button type="button" class="secondary-button" onclick="ajukanUlang('${idAman(t.id)}')">Ajukan ulang</button></div>`:`<div class="approval-note"><b>${escapeHTML(t.nama)}</b><p>Status pengajuan: <strong>Menunggu persetujuan</strong></p>Usaha belum tampil untuk pembeli sampai disetujui Admin.</div>`).join("");
 const reg=document.getElementById("seller-register");
 if(reg&&usahaSayaDimuat&&!reg.dataset.diatur){reg.dataset.diatur="1";reg.open=!milik.length}
 let aktif=milik.find(t=>t.id===input.value);
 if(!aktif&&milik.length===1){input.value=milik[0].id;aktif=milik[0]}
 if(!aktif){input.value="";if(form)form.classList.add("hidden");return}
 if(!jagaForm)muatKelolaToko();
 else{const lbl=document.getElementById("status-toko-label");if(lbl)lbl.textContent="Status: "+(aktif.statusToko||"Belum diketahui")}
}
async function ajukanUlang(id){
 if(!usahaSaya.some(x=>x.id===id))return;
 await jalankan(()=>fbDb.collection("usaha").doc(id).update({status:"menunggu",diperbarui:Date.now()}),"Usaha diajukan ulang. Menunggu persetujuan Admin.");
}
function muatKelolaToko(){
 const aktif=tokoPemilikAktif(),form=document.getElementById("penjual-kelola-form");
 if(!aktif){if(form)form.classList.add("hidden");return}
 const {t,id}=aktif;
 if(form)form.classList.remove("hidden");
 document.getElementById("penjual-nama-toko").value=t.nama||"";
 document.getElementById("penjual-alamat-toko").value=t.alamat||"";
 document.getElementById("penjual-whatsapp-toko").value=t.whatsapp||"";
 document.getElementById("status-toko-label").textContent="Status: "+(t.statusToko||"Belum diketahui");
 const preview=document.getElementById("penjual-foto-profil-preview");if(preview)preview.src=fotoAman(t.foto);
 const fotoInput=document.getElementById("penjual-foto-profil");if(fotoInput)fotoInput.value="";
 const daftar=document.getElementById("daftar-barang-penjual");
 if(daftar)daftar.innerHTML=(t.barang||[]).map((b,j)=>`<article class="seller-product">${b.foto?`<img src="${escapeHTML(fotoAman(b.foto))}" alt="">`:""}<span><b>${escapeHTML(b.nama)}</b><small>Harga: ${b.harga?"Rp "+escapeHTML(b.harga):"Belum diatur"} · Stok: ${Number(b.stok)||0} · ${escapeHTML(b.keterangan||"")}</small></span><div class="seller-product-actions"><button class="auth-secondary" onclick="editBarangPenjual(${j})">Edit</button><button class="auth-secondary" onclick="hapusBarangPenjual('${idAman(id)}',${j})">Hapus</button></div></article>`).join("")||"<p>Belum ada barang. Tambahkan barang melalui formulir di atas.</p>";
}
async function simpanInfoToko(){
 const aktif=tokoPemilikAktif();if(!aktif){alert("Toko tidak ditemukan atau bukan milik akun Anda.");return}
 const nama=document.getElementById("penjual-nama-toko").value.trim(),alamat=document.getElementById("penjual-alamat-toko").value.trim();
 if(!nama||!alamat){alert("Nama dan alamat toko wajib diisi.");return}
 await jalankan(()=>fbDb.collection("usaha").doc(aktif.id).update({nama,alamat,whatsapp:document.getElementById("penjual-whatsapp-toko").value.trim(),diperbarui:Date.now()}),"Informasi toko berhasil diperbarui.");
}
async function simpanFotoProfilToko(){
 const aktif=tokoPemilikAktif();if(!aktif){alert("Pilih toko milik akun Anda.");return}
 const file=document.getElementById("penjual-foto-profil").files[0];
 if(!file){alert("Pilih foto profil toko terlebih dahulu.");return}
 let foto;try{foto=await kompresGambar(file,800,0.72,200000)}catch(e){alert(e.message);return}
 await jalankan(()=>fbDb.collection("usaha").doc(aktif.id).update({foto,diperbarui:Date.now()}),"Foto profil toko berhasil diperbarui.");
}
function editBarangPenjual(j){
 const aktif=tokoPemilikAktif(),b=aktif?.t?.barang?.[j];if(!b)return;
 indeksBarangDiedit=j;
 document.getElementById("barang-nama").value=b.nama||"";
 document.getElementById("barang-harga").value=b.harga||"";
 document.getElementById("barang-stok").value=Number(b.stok)||0;
 document.getElementById("barang-keterangan").value=b.keterangan||"";
 document.getElementById("barang-foto").value="";
 const tombol=document.querySelector('#penjual-kelola-form button[onclick="simpanBarangPenjual()"]');if(tombol)tombol.textContent="Simpan perubahan produk";
 document.getElementById("barang-nama").scrollIntoView({behavior:"smooth",block:"center"});
}
async function simpanBarangPenjual(){
 const aktif=tokoPemilikAktif();if(!aktif){alert("Pilih toko milik akun Anda.");return}
 const nama=document.getElementById("barang-nama").value.trim(),stok=Number(document.getElementById("barang-stok").value),file=document.getElementById("barang-foto").files[0];
 if(!nama||!Number.isFinite(stok)||stok<0){alert("Isi nama barang dan jumlah stok dengan benar.");return}
 let foto="";
 if(file){try{foto=await kompresGambar(file,360,0.7,60000)}catch(e){alert(e.message);return}}
 const barang=(aktif.t.barang||[]).map(b=>Object.assign({},b));
 const lama=indeksBarangDiedit!==null?barang[indeksBarangDiedit]:null;
 const data={nama:nama.slice(0,80),stok:Math.floor(stok),harga:document.getElementById("barang-harga").value.trim().slice(0,30),keterangan:document.getElementById("barang-keterangan").value.trim().slice(0,200),foto:foto||(lama?lama.foto:"")||""};
 if(lama)barang[indeksBarangDiedit]=data;
 else{if(barang.length>=30){alert("Maksimal 30 produk per toko.");return}barang.push(data)}
 if(JSON.stringify(barang).length>600000){alert("Data produk terlalu besar. Hapus beberapa foto produk lalu coba lagi.");return}
 const ok=await jalankan(()=>fbDb.collection("usaha").doc(aktif.id).update({barang,diperbarui:Date.now()}),"Produk berhasil disimpan.");
 if(!ok)return;
 indeksBarangDiedit=null;
 ["barang-nama","barang-stok","barang-harga","barang-keterangan","barang-foto"].forEach(id=>document.getElementById(id).value="");
 const tombol=document.querySelector('#penjual-kelola-form button[onclick="simpanBarangPenjual()"]');if(tombol)tombol.textContent="Simpan produk";
 muatKelolaToko();
}
async function ubahStatusToko(status){
 const aktif=tokoPemilikAktif();if(!aktif){alert("Toko tidak ditemukan atau bukan milik akun Anda.");return}
 if(!["Buka","Tutup"].includes(status))return;
 await jalankan(()=>fbDb.collection("usaha").doc(aktif.id).update({statusToko:status,statusDiperbarui:new Date().toISOString(),diperbarui:Date.now()}));
}
async function hapusBarangPenjual(id,j){
 const t=usahaSaya.find(x=>x.id===id);if(!t||!confirm("Hapus barang ini?"))return;
 const barang=(t.barang||[]).filter((_,k)=>k!==j);
 if(indeksBarangDiedit===j)indeksBarangDiedit=null;
 await jalankan(()=>fbDb.collection("usaha").doc(id).update({barang,diperbarui:Date.now()}));
}

// ----- Admin: persetujuan dan pengelolaan -----
function pastikanAdmin(){if(window.akunAktif?.peran!=="admin"){alert("Akses khusus Admin.");return false}return true}
function catatAdmin(aksi){if(!fbDb||window.akunAktif?.peran!=="admin")return;fbDb.collection("riwayat").add({aksi:String(aksi).slice(0,200),waktu:Date.now(),admin:window.akunAktif.nama}).catch(e=>console.error(e))}
function usahaById(id){return usahaSemua.find(x=>x.id===id)}
async function setujuiUsaha(id){
 if(!pastikanAdmin())return;const t=usahaById(id);if(!t)return;
 const ok=await jalankan(()=>fbDb.collection("usaha").doc(id).update({status:"disetujui",catatanAdmin:"",diperbarui:Date.now()}));
 if(ok)catatAdmin("Menyetujui usaha "+t.nama);
}
async function tolakUsaha(id){
 if(!pastikanAdmin())return;const t=usahaById(id);if(!t)return;
 const alasan=prompt("Alasan penolakan atau perbaikan yang diminta (boleh dikosongkan):","");if(alasan===null)return;
 const ok=await jalankan(()=>fbDb.collection("usaha").doc(id).update({status:"ditolak",catatanAdmin:alasan.trim().slice(0,200),diperbarui:Date.now()}));
 if(ok)catatAdmin("Menolak usaha "+t.nama);
}
async function toggleUsaha(id){
 if(!pastikanAdmin())return;const t=usahaById(id);if(!t)return;
 const ok=await jalankan(()=>fbDb.collection("usaha").doc(id).update({dinonaktif:!t.dinonaktif,diperbarui:Date.now()}));
 if(ok)catatAdmin((t.dinonaktif?"Mengaktifkan ":"Menonaktifkan ")+t.nama);
}
async function hapusUsahaAdmin(id){
 if(!pastikanAdmin())return;const t=usahaById(id);if(!t||!confirm("Hapus usaha ini secara permanen? Unduh cadangan sebelum melanjutkan."))return;
 const ok=await jalankan(()=>fbDb.collection("usaha").doc(id).delete());
 if(ok)catatAdmin("Menghapus permanen usaha "+t.nama);
}
async function toggleAkun(uid){
 if(!pastikanAdmin())return;const a=akunSemua.find(x=>x.id===uid);if(!a)return;
 const ok=await jalankan(()=>fbDb.collection("users").doc(uid).update({dinonaktif:!a.dinonaktif}));
 if(ok)catatAdmin((a.dinonaktif?"Mengaktifkan":"Menonaktifkan")+" akun "+a.nama+" ("+a.hp+")");
}
async function imporBawaan(){
 if(!pastikanAdmin())return;
 const ada=new Set(usahaSemua.map(identitas)),baru=dataAwal.filter(t=>!ada.has(identitas(t)));
 if(!baru.length){alert("Semua toko bawaan sudah ada di database.");return}
 if(!confirm("Impor "+baru.length+" toko bawaan ke database? Setelah itu toko tersebut bisa dikelola dari panel admin."))return;
 const ok=await jalankan(()=>{const b=fbDb.batch();baru.forEach(t=>b.set(fbDb.collection("usaha").doc(),Object.assign({},t,{barang:[],statusToko:"",status:"disetujui",ownerUid:"",ownerHp:"",bawaan:true,dibuat:Date.now(),diperbarui:Date.now(),dinonaktif:false})));return b.commit()},"Toko bawaan berhasil diimpor.");
 if(ok)catatAdmin("Mengimpor "+baru.length+" toko bawaan");
}
function eksporDataUsaha(){unduhJSON(window.akunAktif?.peran==="admin"?usahaSemua:daftarUsaha,"cadangan-dodaka-map.json")}
function eksporSemuaData(){if(!pastikanAdmin())return;unduhJSON({usaha:usahaSemua,akun:akunSemua,tanggalEkspor:new Date().toISOString()},"cadangan-lengkap-dodaka-map.json")}
function tampilkanRingkasan(){const el=document.getElementById("ringkasan-data");if(el)el.innerHTML=`<p><b>${daftarUsaha.length}</b> usaha tampil di peta.</p>`}
function muatPanelAdmin(){
 if(window.akunAktif?.peran!=="admin")return;
 const menunggu=usahaSemua.filter(t=>t.status==="menunggu"),nonaktif=usahaSemua.filter(t=>t.dinonaktif).length;
 const q=id=>document.getElementById(id);
 {const sel=q("ap-usaha");if(sel){const cur=sel.value;const bebas=usahaSemua.filter(t=>!t.ownerUid);sel.innerHTML='<option value="">Tanpa usaha dulu</option>'+bebas.map(t=>`<option value="${escapeHTML(t.id)}">${escapeHTML(t.nama)} (${escapeHTML(t.kategori)})</option>`).join("");if(cur&&bebas.some(t=>t.id===cur))sel.value=cur}}
 q("admin-statistik").innerHTML=`<div><b>${usahaSemua.length}</b><small>Total usaha</small></div><div><b>${akunSemua.length}</b><small>Akun pengguna</small></div><div><b>${menunggu.length}</b><small>Menunggu persetujuan</small></div><div><b>${nonaktif}</b><small>Nonaktif</small></div>`;
 const lokasi=t=>Number.isFinite(Number(t.lat))&&Number.isFinite(Number(t.lng))?`<a target="_blank" rel="noopener" href="https://www.google.com/maps?q=${Number(t.lat)},${Number(t.lng)}">Lihat lokasi</a>`:"";
 q("admin-verifikasi").innerHTML=menunggu.map(t=>`<div class="admin-row"><div><img class="admin-thumb" src="${escapeHTML(fotoAman(t.foto))}" alt=""><b>${escapeHTML(t.nama)}</b><small>${escapeHTML(t.kategori)} · ${escapeHTML(t.alamat)}</small><small>Pemilik: ${escapeHTML(t.ownerHp||"-")} · WA: ${escapeHTML(t.whatsapp||"-")}</small><small>${lokasi(t)}</small></div><div class="admin-actions"><button onclick="setujuiUsaha('${idAman(t.id)}')">Setujui</button><button class="danger-button" onclick="tolakUsaha('${idAman(t.id)}')">Tolak</button></div></div>`).join("")||"<p>Tidak ada usaha yang menunggu persetujuan.</p>";
 q("admin-daftar-usaha").innerHTML=usahaSemua.slice().sort((a,b)=>(b.dibuat||0)-(a.dibuat||0)).map(t=>`<div class="admin-row"><div><b>${escapeHTML(t.nama)}</b><small>${escapeHTML(t.kategori)} · ${escapeHTML(statusPengajuanTeks(t.status))} · ${t.dinonaktif?"Nonaktif":"Aktif"}</small></div><div class="admin-actions">${t.status!=="disetujui"?`<button onclick="setujuiUsaha('${idAman(t.id)}')">Setujui</button>`:""}<button onclick="toggleUsaha('${idAman(t.id)}')">${t.dinonaktif?"Aktifkan":"Nonaktifkan"}</button><button class="danger-button" onclick="hapusUsahaAdmin('${idAman(t.id)}')">Hapus permanen</button></div></div>`).join("")||"<p>Belum ada usaha di database.</p>";
 q("admin-daftar-akun").innerHTML=akunSemua.map(a=>`<div class="admin-row"><div><b>${escapeHTML(a.nama)}</b><small>${escapeHTML(a.hp)} · ${escapeHTML(a.peran)} · ${a.dinonaktif?"Nonaktif":"Aktif"}</small></div><div class="admin-actions"><button onclick="toggleAkun('${idAman(a.id)}')">${a.dinonaktif?"Aktifkan":"Nonaktifkan"}</button></div></div>`).join("")||"<p>Belum ada akun.</p>";
 q("admin-riwayat").innerHTML=riwayatAdmin.map(x=>`<p class="history-item"><b>${escapeHTML(x.aksi)}</b><small>${escapeHTML(new Date(x.waktu||0).toLocaleString("id-ID"))} · ${escapeHTML(x.admin)}</small></p>`).join("")||"<p>Belum ada aktivitas.</p>";
}


// ----- Ubah sandi, lupa sandi, akun buatan admin -----
function pesanSandi(e){const c=(e&&e.code)||"";if(["auth/wrong-password","auth/invalid-credential","auth/invalid-login-credentials"].includes(c))return"Sandi lama salah.";if(c==="auth/weak-password")return"Sandi baru terlalu lemah (minimal 6 karakter).";if(c==="auth/requires-recent-login")return"Silakan keluar lalu masuk lagi, kemudian ulangi.";return pesanErrorAuth(e)}
async function gantiSandi(lama,baru,ulang){
 if(baru.length<6)throw{code:"auth/weak-password"};
 if(baru!==ulang)throw{message:"Sandi baru dan ulangannya tidak sama."};
 if(baru===lama)throw{message:"Sandi baru harus berbeda dari sandi lama."};
 const u=fbAuth.currentUser;if(!u)throw{message:"Anda belum login."};
 await u.reauthenticateWithCredential(firebase.auth.EmailAuthProvider.credential(u.email,lama));
 await u.updatePassword(baru);
}
async function simpanSandiWajib(e){
 e.preventDefault();const p=profilTertunda;if(!p||!fbSiap)return;
 const t=e.target.querySelector("button.primary-button");if(t)t.disabled=true;pesanAuth("Menyimpan...");
 try{
  await gantiSandi(document.getElementById("sw-lama").value,document.getElementById("sw-baru").value,document.getElementById("sw-ulang").value);
  await fbDb.collection("users").doc(p.uid).update({wajibUbahSandi:false});
  e.target.reset();profilTertunda=null;p.wajibUbahSandi=false;pesanAuth("");buatSesi(p);
 }catch(err){console.error(err);pesanAuth(pesanSandi(err))}
 finally{if(t)t.disabled=false}
}
async function ubahSandiProfil(e){
 e.preventDefault();if(!window.akunAktif||!fbSiap)return;
 try{await gantiSandi(document.getElementById("ps-lama").value,document.getElementById("ps-baru").value,document.getElementById("ps-ulang").value);e.target.reset();alert("Sandi berhasil diubah.")}
 catch(err){console.error(err);alert(pesanSandi(err))}
}
function lupaSandi(){
 const pesan="Halo Admin DODAKA MAP, saya lupa sandi akun saya. Nomor HP saya: "+normalisasiNomorHP(document.getElementById("login-hp").value||"");
 if(confirm("Sandi tidak bisa dikirim lewat email. Admin akan mengatur ulang akun Anda dengan sandi sementara. Buka WhatsApp Admin sekarang?"))window.open("https://wa.me/"+ADMIN_HP+"?text="+encodeURIComponent(pesan),"_blank","noopener");
}
// Admin membuat akun penjual lewat koneksi Firebase kedua agar sesi admin tidak terganggu.
async function buatAkunPenjual(e){
 e.preventDefault();if(!pastikanAdmin())return;
 const nama=document.getElementById("ap-nama").value.trim().slice(0,60),hp=normalisasiNomorHP(document.getElementById("ap-hp").value),pass=document.getElementById("ap-pass").value;
 if(!nama||!/^62[0-9]{8,13}$/.test(hp)){alert("Nama atau nomor HP tidak valid.");return}
 if(hp===ADMIN_HP){alert("Nomor ini khusus akun Admin.");return}
 if(pass.length<6){alert("Sandi sementara minimal 6 karakter.");return}
 const lama=akunSemua.filter(a=>a.hp===hp);
 if(lama.length&&!confirm("Nomor ini sudah punya profil ("+lama[0].nama+"). Profil lama diganti dan toko miliknya dihubungkan ke akun baru. Lanjutkan?"))return;
 const tombol=e.target.querySelector("button.primary-button");if(tombol)tombol.disabled=true;
 let app2=null;
 try{
  app2=firebase.apps.find(x=>x.name==="Sekunder")||firebase.initializeApp(window.FIREBASE_CONFIG,"Sekunder");
  const a2=app2.auth();let cred;
  try{cred=await a2.createUserWithEmailAndPassword(hp+DOMAIN_EMAIL,pass)}
  catch(err){if((err.code||"")==="auth/email-already-in-use"){alert("Akun login untuk nomor ini masih ada di Firebase. Hapus dulu di Firebase Console > Authentication (cari "+hp+DOMAIN_EMAIL+"), lalu coba lagi.");return}throw err}
  const uidBaru=cred.user.uid;await a2.signOut();
  const b=fbDb.batch();
  b.set(fbDb.collection("users").doc(uidBaru),{nama,hp,peran:"penjual",dibuat:Date.now(),dinonaktif:false,wajibUbahSandi:true});
  lama.forEach(x=>b.delete(fbDb.collection("users").doc(x.id)));
  const toko=usahaSemua.filter(t=>t.ownerHp===hp);
  const pilihId=(document.getElementById("ap-usaha")||{}).value||"";
  const pilih=usahaSemua.find(t=>t.id===pilihId&&!t.ownerUid);
  if(pilih&&!toko.some(t=>t.id===pilih.id))toko.push(pilih);
  toko.forEach(t=>b.update(fbDb.collection("usaha").doc(t.id),{ownerUid:uidBaru,ownerHp:hp,diperbarui:Date.now()}));
  await b.commit();
  e.target.reset();
  catatAdmin("Membuat/mengatur ulang akun penjual "+nama+" ("+hp+")");
  alert("Akun siap. Berikan nomor HP dan sandi sementara ini ke penjual. Ia akan diminta membuat sandi baru saat masuk."+(toko.length?" "+toko.length+" toko dihubungkan kembali.":""));
 }catch(err){console.error(err);alert(pesanErrorAuth(err))}
 finally{if(tombol)tombol.disabled=false}
}

// ----- Rasa aplikasi Android: dialog, efek tekan, tombol Kembali -----
(function(){
 const antre=[];let kotak=null;
 function tampil(){
  if(kotak||!antre.length)return;
  kotak=document.createElement("div");kotak.className="md-dialog-layar";
  kotak.innerHTML='<div class="md-dialog" role="alertdialog" aria-modal="true"><p></p><div class="md-dialog-aksi"><button type="button">OK</button></div></div>';
  kotak.querySelector("p").textContent=antre.shift();
  const tombol=kotak.querySelector("button");
  tombol.addEventListener("click",()=>{kotak.remove();kotak=null;tampil()});
  document.body.appendChild(kotak);tombol.focus();
 }
 window.alert=function(pesan){antre.push(String(pesan==null?"":pesan));tampil()};
})();
document.addEventListener("pointerdown",e=>{
 const b=e.target.closest&&e.target.closest(".primary-button,.secondary-button,.bottom-nav button,.icon-button,.category,.md-dialog-aksi button");
 if(!b||b.disabled)return;
 const r=b.getBoundingClientRect(),d=Math.max(r.width,r.height)*1.6,s=document.createElement("span");
 s.className="ripple";s.style.cssText="width:"+d+"px;height:"+d+"px;left:"+(e.clientX-r.left-d/2)+"px;top:"+(e.clientY-r.top-d/2)+"px";
 b.appendChild(s);setTimeout(()=>s.remove(),600);
},{passive:true});
(function(){
 const asli=window.tampilkanHalaman;if(typeof asli!=="function")return;
 let kini="bagian-beranda",dariBack=false;
 window.tampilkanHalaman=function(id){
  const hasil=asli.apply(this,arguments);
  if(dariBack||id===kini){kini=id;return hasil}
  kini=id;try{history.pushState({h:id},"")}catch(e){}
  return hasil;
 };
 window.addEventListener("popstate",e=>{
  const id=(e.state&&e.state.h)||"bagian-beranda";
  dariBack=true;try{window.tampilkanHalaman(id)}finally{dariBack=false}
 });
 try{history.replaceState({h:"bagian-beranda"},"")}catch(e){}
})();

// ----- Mulai -----
bangunDaftarUsaha();
document.addEventListener("DOMContentLoaded",()=>{
 const galat=mulaiFirebase();
 if(galat){tampilAuth("auth-choice");pesanAuth(galat);return}
 pasangAuth();
});
