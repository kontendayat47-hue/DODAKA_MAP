// Isi dengan konfigurasi Firebase project Anda
// (Firebase Console > Project settings > Your apps > Web app > firebaseConfig).
// Kunci ini memang publik; keamanan data diatur oleh aturan Firestore.
window.FIREBASE_CONFIG = {
  apiKey: "ISI_API_KEY",
  authDomain: "ISI_PROJECT_ID.firebaseapp.com",
  projectId: "ISI_PROJECT_ID",
  storageBucket: "ISI_PROJECT_ID.appspot.com",
  messagingSenderId: "ISI_SENDER_ID",
  appId: "ISI_APP_ID"
};
