const KUNCI_DATA="usahaDodaka";
const TITIK_AWAL=[-1.0344966,101.6735537];
const dataAwal=[
 {nama:"Toko supek",kategori:"Laundry",alamat:"Blok B",whatsapp:"085219129942",lat:-1.0697072443667706,lng:101.54896438121797,foto:"assets/toko-supek.jpg"},
 {nama:"Makmur bengkel",kategori:"Bengkel",alamat:"Blok B",whatsapp:"08678985",lat:-1.0713821591259023,lng:101.55156612396242,foto:"assets/bengkel.jpg"},
 {nama:"Ampera",kategori:"Rumah Makan",alamat:"Blok B",whatsapp:"",lat:-1.0678038331795667,lng:101.54707144789428,foto:"assets/ampera.jpg"},
 {nama:"Lekman",kategori:"Sembako",alamat:"Blok B",whatsapp:"08",lat:-1.0491129089580877,lng:101.54813289642334,foto:"assets/suasana-blok-b.jpg"},
 {nama:"Pandi",kategori:"Barbershop",alamat:"Blok B",whatsapp:"088",lat:-1.0502720992398886,lng:101.54854059219362,foto:"assets/suasana-blok-b.jpg"},
 {nama:"M HIDAYAT",kategori:"Barbershop",alamat:"Blok B",whatsapp:"",lat:-1.0510,lng:101.5490,foto:"assets/suasana-blok-b.jpg"},
 {nama:"M HIDAYAT",kategori:"Warung",alamat:"Blok B",whatsapp:"",lat:-1.0520,lng:101.5500,foto:"assets/suasana-blok-b.jpg"}
];
let daftarUsaha=[];
try{const tersimpan=JSON.parse(localStorage.getItem(KUNCI_DATA)||"[]");daftarUsaha=Array.isArray(tersimpan)?tersimpan:[]}catch(e){daftarUsaha=[]}
function identitas(x){return [x.nama||"",x.kategori||"",x.alamat||""].map(v=>String(v).trim().toLowerCase()).join("|")}
let berubah=false;dataAwal.forEach(t=>{if(!daftarUsaha.some(x=>identitas(x)===identitas(t))){daftarUsaha.push(t);berubah=true}});
if(berubah)localStorage.setItem(KUNCI_DATA,JSON.stringify(daftarUsaha));
let peta=null,petaTambah=null,penandaSementara=null,lokasiDipilih=null,kategoriAktif="Semua",semuaPenanda=[],indeksBarangDiedit=null;
const ikonKategori={"Warung":"🛒","Sembako":"🛒","Bengkel":"🔧","Laundry":"🧺","Rumah Makan":"🍜","Barbershop":"✂️","Lainnya":"📍"};
function simpanKePerangkat(){localStorage.setItem(KUNCI_DATA,JSON.stringify(daftarUsaha))}
function escapeHTML(s){return String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
function buatPeta(el,zoom){
  const map=L.map(el,{zoomControl:true}).setView(TITIK_AWAL,zoom);

  // Peta dasar: citra satelit Esri
  const satelit=L.tileLayer(
    "https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}",
    {
      maxZoom:19,
      attribution:"Tiles &copy; Esri"
    }
  );

  // Lapisan jalan dan batas wilayah di atas citra satelit
  const jalan=L.tileLayer(
    "https://server.arcgisonline.com/ArcGIS/rest/services/Reference/World_Transportation/MapServer/tile/{z}/{y}/{x}",
    {
      maxZoom:19,
      attribution:"Esri"
    }
  );

  // Lapisan nama tempat agar lokasi lebih mudah dikenali
  const namaTempat=L.tileLayer(
    "https://server.arcgisonline.com/ArcGIS/rest/services/Reference/World_Boundaries_and_Places/MapServer/tile/{z}/{y}/{x}",
    {
      maxZoom:19,
      attribution:"Esri"
    }
  );

  // Aktifkan satelit, jalan, dan nama tempat
  satelit.addTo(map);
  jalan.addTo(map);
  namaTempat.addTo(map);

  // Pengguna dapat berpindah antara peta satelit dan peta jalan
  const petaJalan=L.tileLayer(
    "https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png",
    {
      maxZoom:19,
      attribution:"&copy; OpenStreetMap contributors"
    }
  );
  L.control.layers(
    {"Satelit":satelit,"Peta jalan":petaJalan},
    {"Jalan & batas":jalan,"Nama tempat":namaTempat},
    {collapsed:true}
  ).addTo(map);

  return map;
}
function mulaiPeta(){if(!window.L)return; peta=buatPeta("peta",15);peta.on("click",e=>{if(document.getElementById("form-usaha").classList.contains("hidden"))return;lokasiDipilih=e.latlng;if(penandaSementara)penandaSementara.remove();penandaSementara=L.marker(e.latlng).addTo(peta).bindPopup("Lokasi usaha dipilih").openPopup()});petaTambah=buatPeta("peta-tambah",15);petaTambah.on("click",e=>{lokasiDipilih=e.latlng;if(penandaSementara)penandaSementara.remove();penandaSementara=L.marker(e.latlng).addTo(petaTambah).bindPopup("Lokasi usaha dipilih").openPopup()});document.querySelectorAll(".category").forEach(b=>b.addEventListener("click",()=>{pilihKategoriDanBukaPeta(b.dataset.kategori)}));tampilkanSemuaUsaha()}
function pilihKategoriDanBukaPeta(kategori){
  kategoriAktif=kategori||"Semua";
  document.querySelectorAll(".category").forEach(b=>b.classList.toggle("active",b.dataset.kategori===kategoriAktif));
  const cariBeranda=document.getElementById("kolom-cari");
  const cariLengkap=document.getElementById("cari-usaha-lengkap");
  if(cariBeranda)cariBeranda.value="";
  if(cariLengkap)cariLengkap.value="";
  const cariPeta=document.getElementById("map-search-input");if(cariPeta)cariPeta.value="";
  perbaruiInfoFilterPeta();
  kePeta();
  setTimeout(()=>{tampilkanSemuaUsaha();if(peta)peta.invalidateSize()},220);
}
function perbaruiInfoFilterPeta(){
  const label=document.getElementById("label-filter-peta");
  const judul=document.getElementById("judul-peta-kategori");
  const deskripsi=document.getElementById("deskripsi-peta-kategori");
  if(label)label.textContent=kategoriAktif==="Semua"?"Semua kategori":"Kategori: "+kategoriAktif;
  if(judul)judul.textContent=kategoriAktif==="Semua"?"Temukan toko di peta":"Peta usaha "+kategoriAktif;
  if(deskripsi)deskripsi.textContent=kategoriAktif==="Semua"?"Blok B · Sitiung 1 · Dharmasraya":"Lokasi usaha kategori "+kategoriAktif+" di Blok B";
  document.querySelectorAll(".map-category-chip").forEach(b=>b.classList.toggle("active",b.dataset.mapKategori===kategoriAktif));
}
function resetKategoriPeta(){pilihKategoriDanBukaPeta("Semua")}
function ikonToko(k){return ikonKategori[k]||"📍"}
function kontenPopupToko(t){
  const foto=escapeHTML(t.foto||"assets/suasana-blok-b.jpg");
  const wa=nomorWA(t.whatsapp);
  const status=t.statusToko||"Belum diatur";
  const statusClass=status==="Buka"?"is-open":"is-closed";
  const arah=(Number.isFinite(Number(t.lat))&&Number.isFinite(Number(t.lng)))?`https://www.google.com/maps/dir/?api=1&destination=${encodeURIComponent(t.lat+","+t.lng)}`:"#";
  const barang=(t.barang||[]).slice(0,4).map(b=>`<div class="map-popup-product">${b.foto?`<img src="${escapeHTML(b.foto)}" alt="">`:""}<span><b>${escapeHTML(b.nama)}</b><small>Stok: ${Number(b.stok)||0}${b.harga?` · Rp ${escapeHTML(b.harga)}`:""}</small></span></div>`).join("");
  return `<div class="map-shop-popup"><img class="map-popup-cover" src="${foto}" alt="Foto ${escapeHTML(t.nama)}" onerror="this.src='assets/suasana-blok-b.jpg'"><div class="map-popup-body"><h3>${escapeHTML(t.nama)}</h3><p class="map-popup-category">${ikonToko(t.kategori)} ${escapeHTML(t.kategori||"Usaha")}</p><p>📍 ${escapeHTML(t.alamat||"Alamat belum diisi")}</p><p class="shop-status ${statusClass}">● ${escapeHTML(status)}</p>${barang?`<div class="map-popup-stock"><b>Info barang</b>${barang}</div>`:""}<div class="map-popup-actions">${wa?`<a class="map-popup-wa" target="_blank" rel="noopener" href="https://wa.me/${wa}">WhatsApp</a>`:""}<a class="map-popup-directions" target="_blank" rel="noopener" href="${arah}">Petunjuk arah</a></div></div></div>`;
}
function tampilkanSemuaUsaha(){if(!peta)return;semuaPenanda.forEach(m=>m.remove());semuaPenanda=[];const q=(document.getElementById("kolom-cari")?.value||"").toLowerCase().trim();const hasil=daftarUsaha.filter(t=>{const cocok=[t.nama,t.kategori,t.alamat].join(" ").toLowerCase().includes(q);const kat=kategoriAktif==="Semua"|| t.kategori===kategoriAktif||(kategoriAktif==="Lainnya"&&!Object.keys(ikonKategori).includes(t.kategori));return cocok&&kat&&!t.dinonaktif&&t.statusPengajuan!=='Menunggu'&&t.verifikasi!=='Ditolak'});const infoPeta=document.getElementById("jumlah-peta-kategori");if(infoPeta)infoPeta.textContent=hasil.length+" usaha ditemukan pada kategori ini";hasil.forEach(t=>{if(Number.isFinite(Number(t.lat))&&Number.isFinite(Number(t.lng))){const marker=L.marker([Number(t.lat),Number(t.lng)],{icon:L.divIcon({className:"dodaka-map-marker-wrap",html:`<span class="dodaka-map-marker ${t.statusToko==="Buka"?"status-open":t.statusToko==="Tutup"?"status-closed":"status-unknown"}"><i>${ikonToko(t.kategori)}</i></span>`,iconSize:[38,44],iconAnchor:[19,39]})}).addTo(peta).bindTooltip(escapeHTML(t.nama),{permanent:true,direction:"top",offset:[0,-28],className:"business-label"});marker.bindPopup(kontenPopupToko(t),{maxWidth:290,minWidth:230,closeButton:true,autoPan:true});semuaPenanda.push(marker)}});document.getElementById("jumlah-usaha").textContent=hasil.length+" usaha ditemukan";const wadah=document.getElementById("kartu-usaha");wadah.innerHTML=hasil.map((t,i)=>{const wa=nomorWA(t.whatsapp);const foto=t.foto||"assets/suasana-blok-b.jpg";const arah=Number.isFinite(Number(t.lat))&&Number.isFinite(Number(t.lng))?`https://www.google.com/maps/dir/?api=1&destination=${t.lat},${t.lng}`:"#";return `<article class="business-card"><img src="${escapeHTML(foto)}" alt="Foto ${escapeHTML(t.nama)}" onerror="this.src='assets/suasana-blok-b.jpg'"><div class="business-info"><h3>${escapeHTML(t.nama)}</h3><p>${ikonToko(t.kategori)} ${escapeHTML(t.kategori)}</p><p>📍 ${escapeHTML(t.alamat||"Alamat belum diisi")}</p><p class="shop-status ${t.statusToko==='Buka'?'is-open':t.statusToko==='Tutup'?'is-closed':'is-unknown'}">● ${escapeHTML(t.statusToko||'Status belum diatur')}</p>${(t.barang||[]).length?`<div class="buyer-products"><b>Barang tersedia</b>${t.barang.map(b=>`<div class="buyer-product">${b.foto?`<img src="${b.foto}" alt="">`:''}<span><b>${escapeHTML(b.nama)}</b><small>Stok: ${Number(b.stok)||0} · ${escapeHTML(b.keterangan||'')}</small>${b.harga?`<small>Rp ${escapeHTML(b.harga)}</small>`:''}</span></div>`).join('')}</div>`:''}<div class="card-actions">${wa?`<a target="_blank" rel="noopener" href="https://wa.me/${wa}">WhatsApp</a>`:""}<a target="_blank" rel="noopener" href="${arah}">Petunjuk arah</a></div></div></article>`}).join("");const ringkas=document.getElementById("ringkas-usaha");if(ringkas)ringkas.innerHTML=wadah.innerHTML.slice(0,12000)}
function nomorWA(n){let x=String(n||"").replace(/\D/g,"");if(x.startsWith("0"))x="62"+x.slice(1);return x}
function simpanUsaha(){if(!window.akunAktif||window.akunAktif.peran!=="admin"){alert("Hanya admin yang boleh menambahkan toko.");return}const nama=document.getElementById("nama").value.trim(),kategori=document.getElementById("kategori-usaha").value,alamat=document.getElementById("alamat").value.trim(),whatsapp=document.getElementById("whatsapp").value.trim();if(!nama||!kategori||!alamat){alert("Lengkapi nama, kategori, dan alamat usaha.");return}if(!lokasiDipilih){alert("Ketuk peta untuk memilih lokasi usaha.");return}daftarUsaha.push({nama,kategori,alamat,whatsapp,lat:lokasiDipilih.lat,lng:lokasiDipilih.lng,foto:"assets/suasana-blok-b.jpg"});simpanKePerangkat();["nama","alamat","whatsapp"].forEach(id=>document.getElementById(id).value="");document.getElementById("kategori-usaha").value="";if(penandaSementara){penandaSementara.remove();penandaSementara=null}lokasiDipilih=null;alert("Usaha berhasil disimpan.");kePeta();tampilkanSemuaUsaha()}
function keLokasiAwal(){if(peta)peta.setView(TITIK_AWAL,15)}
function gunakanLokasiSaya(){if(!peta)return;if(!navigator.geolocation){alert("HP atau browser tidak mendukung lokasi.");return}navigator.geolocation.getCurrentPosition(pos=>{const titik=[pos.coords.latitude,pos.coords.longitude];peta.setView(titik,17);if(window.penandaLokasiSaya)window.penandaLokasiSaya.remove();window.penandaLokasiSaya=L.circleMarker(titik,{radius:9,color:"#fff",weight:3,fillColor:"#1688ff",fillOpacity:1}).addTo(peta).bindPopup("Lokasi Anda").openPopup()},()=>alert("Lokasi belum dapat diakses. Aktifkan GPS dan izinkan akses lokasi."),{enableHighAccuracy:true,timeout:12000,maximumAge:60000})}
function tampilkanRingkasan(){document.getElementById("ringkasan-data").innerHTML=`<p><b>${daftarUsaha.length}</b> data usaha tersimpan di perangkat ini.</p>`}
function eksporDataUsaha(){const blob=new Blob([JSON.stringify(daftarUsaha,null,2)],{type:"application/json"});const url=URL.createObjectURL(blob);const a=document.createElement("a");a.href=url;a.download="cadangan-dodaka-map.json";a.click();URL.revokeObjectURL(url)}
document.addEventListener("DOMContentLoaded",mulaiPeta);
if("serviceWorker" in navigator)window.addEventListener("load",()=>navigator.serviceWorker.register("./service-worker.js").catch(()=>{}));


// ===== AKUN DAN HAK AKSES (PROTOTIPE LOKAL) =====
const KEY_AKUN="dodakaAkunLokal", KEY_SESI="dodakaSesiLokal";
window.akunAktif=null;
function normalisasiNomorHP(n){let x=String(n||"").replace(/\D/g,"");if(x.startsWith("0"))x=x.slice(1);if(x.startsWith("62"))x=x.slice(2);return "62"+x;}
function bacaAkun(){try{return JSON.parse(localStorage.getItem(KEY_AKUN)||"[]")}catch(e){return []}}
function tampilAuth(id){document.querySelectorAll(".auth-view").forEach(x=>x.classList.add("hidden"));document.getElementById(id).classList.remove("hidden");document.getElementById("auth-pesan").textContent=""}
function bukaDaftar(){tampilAuth("form-daftar")}function bukaLogin(){tampilAuth("form-login")}function kembaliAuth(){tampilAuth("auth-choice")}
const ADMIN_HP="6285219129942";
const ADMIN_PASS="bukasandi123";
function daftarAkun(e){
 e.preventDefault();
 const hp=normalisasiNomorHP(document.getElementById("auth-hp").value),pass=document.getElementById("auth-pass").value;
 if(!/^62[0-9]{8,13}$/.test(hp)){document.getElementById("auth-pesan").textContent="Masukkan nomor HP yang valid.";return}
 if(pass.length<6){document.getElementById("auth-pesan").textContent="Password minimal 6 karakter.";return}
 if(hp===ADMIN_HP){document.getElementById("auth-pesan").textContent="Nomor ini khusus akun Admin.";return}
 const akun=bacaAkun();if(akun.some(a=>normalisasiNomorHP(a.hp)===hp)){document.getElementById("auth-pesan").textContent="Nomor HP sudah terdaftar. Silakan login.";return}
 // Nama awal dibuat otomatis; jenis akun mengikuti pilihan saat pendaftaran.
 const peran=document.querySelector("input[name='jenis-akun']:checked")?.value==="penjual"?"penjual":"pembeli";
 const a={nama:"Pengguna "+hp.slice(-4),hp,pass,peran};
 akun.push(a);localStorage.setItem(KEY_AKUN,JSON.stringify(akun));buatSesi(a);
}
function loginAkun(e){e.preventDefault();const hp=normalisasiNomorHP(document.getElementById("login-hp").value),pass=document.getElementById("login-pass").value;
if(hp===ADMIN_HP&&pass===ADMIN_PASS){buatSesi({nama:"Admin DODAKA MAP",hp:ADMIN_HP,peran:"admin"});return}
const a=bacaAkun().find(x=>x.hp===hp&&x.pass===pass&&!x.dinonaktif);if(!a){document.getElementById("auth-pesan").textContent="Nomor HP atau kata sandi salah.";return}buatSesi(a)}
function buatSesi(a){window.akunAktif=a;localStorage.setItem(KEY_SESI,JSON.stringify({hp:a.hp}));document.getElementById("auth-gate").classList.add("hidden");if(typeof keBeranda==="function")keBeranda();document.getElementById("info-akun").innerHTML=`<p><b>${escapeHTML(a.nama)}</b></p><p>Jenis akun: <b>${escapeHTML(a.peran.toUpperCase())}</b></p>`;aturHakAkses();if(a.peran==="admin"&&typeof muatPanelAdmin==="function")muatPanelAdmin();if(a.peran==="penjual"&&typeof siapkanPilihanTokoPenjual==="function"){siapkanPilihanTokoPenjual();keKelolaPenjual()}}
function aturHakAkses(){const admin=window.akunAktif?.peran==="admin";const penjual=window.akunAktif?.peran==="penjual";const kelola=document.getElementById('menu-kelola-penjual');if(kelola)kelola.classList.toggle('hidden',!penjual);document.querySelectorAll('[onclick="keTambah()"]').forEach(b=>b.classList.toggle("hidden",!admin));const tambahNav=document.querySelector('.bottom-nav button[onclick="keTambah()"]');if(tambahNav)tambahNav.classList.toggle("hidden",!admin);const menuTambah=document.getElementById("menu-tambah-usaha");if(menuTambah)menuTambah.classList.toggle("hidden",!admin);if(!admin&&document.getElementById("form-usaha"))document.getElementById("form-usaha").classList.add("hidden");const menu=document.getElementById("menu-profil-role");if(menu)menu.innerHTML=admin?`<button class="primary-button" onclick="keAdmin()">Buka Panel Admin</button><button class="secondary-button" onclick="keTambah()">Tambah usaha</button>`:penjual?`<button class="primary-button" onclick="keKelolaPenjual()">TOKO SAYA</button>`:"";}
function tokoPemilikAktif(){
 const input=document.getElementById('penjual-pilih-toko');
 if(!input||input.value==='')return null;
 const i=Number(input.value);
 const t=Number.isInteger(i)&&i>=0?daftarUsaha[i]:null;
 return t&&t.ownerHp===window.akunAktif?.hp?{t,i}:null;
}
function pilihTokoPemilik(i){
 const t=daftarUsaha[i];
 if(!t||t.ownerHp!==window.akunAktif?.hp){alert('Toko ini bukan milik akun Anda.');return}
 document.getElementById('penjual-pilih-toko').value=String(i);
 muatKelolaToko();
}
function siapkanPilihanTokoPenjual(){
 const hp=window.akunAktif?.hp;
 const milik=daftarUsaha.map((t,i)=>({t,i})).filter(x=>x.t.ownerHp===hp);
 const list=document.getElementById('seller-store-list');
 const info=document.getElementById("seller-approval-info");
 const form=document.getElementById('penjual-kelola-form');
 if(list)list.innerHTML=milik.map(({t,i})=>`<article class="seller-store-card"><img src="${escapeHTML(t.foto||'assets/suasana-blok-b.jpg')}" alt="Foto ${escapeHTML(t.nama)}" onerror="this.src='assets/suasana-blok-b.jpg'"><div class="seller-store-card-info"><b>${escapeHTML(t.nama)}</b><small>${escapeHTML(t.alamat||'Alamat belum diisi')}</small><span class="shop-status ${t.statusToko==='Buka'?'is-open':t.statusToko==='Tutup'?'is-closed':'is-unknown'}">${t.statusToko==='Buka'?'● BUKA':t.statusToko==='Tutup'?'● TUTUP':'● BELUM DIKETAHUI'}</span><small>Pengajuan: ${escapeHTML(t.statusPengajuan||t.verifikasi||'Belum diketahui')}</small></div><button type="button" class="primary-button" onclick="pilihTokoPemilik(${i})">Kelola toko</button></article>`).join('')||'<div class="approval-note">Akun ini belum memiliki toko. Daftarkan toko terlebih dahulu untuk mulai mengelolanya.</div>';
 if(info)info.innerHTML=milik.some(x=>x.t.statusPengajuan!=="Disetujui")?milik.filter(x=>x.t.statusPengajuan!=="Disetujui").map(x=>`<div class="approval-note"><b>${escapeHTML(x.t.nama)}</b><p>Status pengajuan: <strong>${escapeHTML(x.t.statusPengajuan||x.t.verifikasi||"Menunggu")}</strong></p>Toko belum tampil untuk pembeli sampai disetujui Admin.</div>`).join(""):"";
 const active=tokoPemilikAktif();
 if(active&&milik.some(x=>x.i===active.i)){muatKelolaToko();return}
 if(milik.length===1){document.getElementById('penjual-pilih-toko').value=String(milik[0].i);muatKelolaToko()}
 else if(form)form.classList.add('hidden');
}
function muatKelolaToko(){
 const active=tokoPemilikAktif(),form=document.getElementById('penjual-kelola-form');
 if(!active){if(form)form.classList.add('hidden');return}
 const {t,i}=active;
 if(form)form.classList.remove('hidden');
 document.getElementById('penjual-nama-toko').value=t.nama||'';
 document.getElementById('penjual-alamat-toko').value=t.alamat||'';
 document.getElementById('penjual-whatsapp-toko').value=t.whatsapp||'';
 document.getElementById('status-toko-label').textContent='Status: '+(t.statusToko||'Belum diketahui');
 const preview=document.getElementById('penjual-foto-profil-preview');
 if(preview)preview.src=t.foto||'assets/suasana-blok-b.jpg';
 const fotoInput=document.getElementById('penjual-foto-profil');if(fotoInput)fotoInput.value='';
 const daftar=document.getElementById('daftar-barang-penjual');
 if(daftar)daftar.innerHTML=(t.barang||[]).map((b,j)=>`<article class="seller-product">${b.foto?`<img src="${b.foto}" alt="">`:''}<span><b>${escapeHTML(b.nama)}</b><small>Harga: ${b.harga?'Rp '+escapeHTML(b.harga):'Belum diatur'} · Stok: ${Number(b.stok)||0} · ${escapeHTML(b.keterangan||'')}</small></span><div class="seller-product-actions"><button class="auth-secondary" onclick="editBarangPenjual(${j})">Edit</button><button class="auth-secondary" onclick="hapusBarangPenjual(${i},${j})">Hapus</button></div></article>`).join('')||'<p>Belum ada barang. Tambahkan barang melalui formulir di atas.</p>';
}
function simpanInfoToko(){
 const active=tokoPemilikAktif();if(!active){alert('Toko tidak ditemukan atau bukan milik akun Anda.');return}
 const nama=document.getElementById('penjual-nama-toko').value.trim(),alamat=document.getElementById('penjual-alamat-toko').value.trim();
 if(!nama||!alamat){alert('Nama dan alamat toko wajib diisi.');return}
 active.t.nama=nama;active.t.alamat=alamat;active.t.whatsapp=document.getElementById('penjual-whatsapp-toko').value.trim();
 simpanKePerangkat();siapkanPilihanTokoPenjual();tampilkanSemuaUsaha();alert('Informasi toko berhasil diperbarui.');
}
function simpanFotoProfilToko(){
 const active=tokoPemilikAktif(),i=active?.i,t=active?.t;
 if(!t||t.ownerHp!==window.akunAktif?.hp){alert('Pilih toko milik akun Anda.');return}
 const file=document.getElementById('penjual-foto-profil').files[0];
 if(!file){alert('Pilih foto profil toko terlebih dahulu.');return}
 if(!file.type.startsWith('image/')){alert('File harus berupa gambar.');return}
 if(file.size>2500000){alert('Ukuran foto maksimal 2,5 MB.');return}
 const r=new FileReader();
 r.onload=()=>{t.foto=r.result;simpanKePerangkat();muatKelolaToko();tampilkanSemuaUsaha();alert('Foto profil toko berhasil diperbarui.')};
 r.readAsDataURL(file);
}
function editBarangPenjual(j){
 const active=tokoPemilikAktif(),t=active?.t,b=t?.barang?.[j];if(!b)return;
 indeksBarangDiedit=j;
 document.getElementById('barang-nama').value=b.nama||'';
 document.getElementById('barang-harga').value=b.harga||'';
 document.getElementById('barang-stok').value=Number(b.stok)||0;
 document.getElementById('barang-keterangan').value=b.keterangan||'';
 document.getElementById('barang-foto').value='';
 const tombol=document.querySelector('#penjual-kelola-form button[onclick="simpanBarangPenjual()"]');
 if(tombol)tombol.textContent='Simpan perubahan produk';
 document.getElementById('barang-nama').scrollIntoView({behavior:'smooth',block:'center'});
}
function simpanBarangPenjual(){
 const active=tokoPemilikAktif(),t=active?.t;if(!t||t.ownerHp!==window.akunAktif?.hp){alert('Pilih toko milik akun Anda.');return}
 const nama=document.getElementById('barang-nama').value.trim(),stok=Number(document.getElementById('barang-stok').value),file=document.getElementById('barang-foto').files[0];
 if(!nama||!Number.isFinite(stok)||stok<0){alert('Isi nama barang dan jumlah stok dengan benar.');return}
 const simpan=foto=>{t.barang=t.barang||[];const data={nama,stok,harga:document.getElementById('barang-harga').value.trim(),keterangan:document.getElementById('barang-keterangan').value.trim(),foto:foto||(indeksBarangDiedit!==null?t.barang[indeksBarangDiedit]?.foto:'')||''};if(indeksBarangDiedit!==null&&t.barang[indeksBarangDiedit])t.barang[indeksBarangDiedit]=data;else t.barang.push(data);indeksBarangDiedit=null;simpanKePerangkat();['barang-nama','barang-stok','barang-harga','barang-keterangan','barang-foto'].forEach(id=>document.getElementById(id).value='');const tombol=document.querySelector('#penjual-kelola-form button[onclick="simpanBarangPenjual()"]');if(tombol)tombol.textContent='Simpan produk';muatKelolaToko();tampilkanSemuaUsaha();alert('Produk berhasil disimpan.')};
 if(file){if(file.size>1500000){alert('Ukuran foto maksimal 1,5 MB.');return}if(!file.type.startsWith('image/')){alert('File harus berupa gambar.');return}const r=new FileReader();r.onload=()=>simpan(r.result);r.readAsDataURL(file)}else simpan('');
}
function ubahStatusToko(status){const active=tokoPemilikAktif(),t=active?.t;if(!t||t.ownerHp!==window.akunAktif?.hp){alert('Toko tidak ditemukan atau bukan milik akun Anda.');return}if(!['Buka','Tutup'].includes(status))return;t.statusToko=status;t.statusDiperbarui=new Date().toISOString();simpanKePerangkat();muatKelolaToko();siapkanPilihanTokoPenjual();tampilkanSemuaUsaha()}
function hapusBarangPenjual(i,j){if(!confirm('Hapus barang ini?'))return;daftarUsaha[i].barang.splice(j,1);if(indeksBarangDiedit===j)indeksBarangDiedit=null;simpanKePerangkat();muatKelolaToko();tampilkanSemuaUsaha()}

function keluarAkun(){localStorage.removeItem(KEY_SESI);sessionStorage.removeItem(KEY_SESI);window.akunAktif=null;document.getElementById("auth-gate").classList.remove("hidden");kembaliAuth();kePeta()}
document.addEventListener("DOMContentLoaded",()=>{const s=localStorage.getItem(KEY_SESI);if(s){try{const hp=normalisasiNomorHP(JSON.parse(s).hp);if(hp===ADMIN_HP){buatSesi({nama:"Admin DODAKA MAP",hp:ADMIN_HP,peran:"admin"});return}const a=bacaAkun().find(x=>normalisasiNomorHP(x.hp)===hp&&!x.dinonaktif);if(a){buatSesi(a);return}localStorage.removeItem(KEY_SESI)}catch(e){console.error(e);localStorage.removeItem(KEY_SESI)}}document.getElementById("auth-gate").classList.remove("hidden")});

let petaDaftarPenjual=null;
window.lokasiDaftarPenjual=null;
function siapkanPetaDaftarPenjual(){
 const el=document.getElementById("peta-daftar-penjual");if(!el||!window.L)return;
 if(!petaDaftarPenjual){
  petaDaftarPenjual=buatPeta("peta-daftar-penjual",16);
  petaDaftarPenjual.on("click",e=>{
   window.lokasiDaftarPenjual={lat:e.latlng.lat,lng:e.latlng.lng};
   if(window.markerDaftarPenjual)window.markerDaftarPenjual.remove();
   window.markerDaftarPenjual=L.marker(e.latlng).addTo(petaDaftarPenjual).bindPopup("Lokasi toko yang diajukan").openPopup();
   document.getElementById("lokasi-daftar-label").textContent="Lokasi dipilih: "+e.latlng.lat.toFixed(6)+", "+e.latlng.lng.toFixed(6);
  });
 }
 setTimeout(()=>petaDaftarPenjual.invalidateSize(),300);
}
document.addEventListener("DOMContentLoaded",()=>{
 document.querySelectorAll('input[name="jenis-akun"]').forEach(r=>r.addEventListener("change",()=>{
  const penjual=document.querySelector('input[name="jenis-akun"]:checked')?.value==="penjual";
  document.getElementById("form-data-toko-daftar").classList.toggle("hidden",!penjual);
  if(penjual)siapkanPetaDaftarPenjual();
 }));
});
